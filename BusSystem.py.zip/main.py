"""
Bangladesh Bus Ticket Booking System
Main program file - Run this file to start the application
"""

from bus_system import BusSystem

def clear_screen():
    """Clear the console screen"""
    import os
    os.system('cls' if os.name == 'nt' else 'clear')

def display_user_menu():
    """Display the main user menu"""
    print("\n" + "="*50)
    print("BANGLADESH BUS TICKET BOOKING SYSTEM")
    print("="*50)
    print("1. Admin Login")
    print("2.  Book Ticket")
    print("3. View All Buses")
    print("4.  Exit")
    print("="*50)

def display_admin_menu():
    """Display the admin menu"""
    print("\n" + "="*50)
    print("ADMIN MENU")
    print("="*50)
    print("1. ➕ Add New Bus")
    print("2. View All Buses")
    print("3.  View All Passengers")
    print("4.  Logout")
    print("="*50)

def handle_add_bus(system):
    """Handle adding a new bus"""
    print("\n" + "="*40)
    print("➕ ADD NEW BUS")
    print("="*40)
    
    bus_number = input("Enter Bus Number (e.g., B006): ").strip().upper()
    route = input("Enter Route (e.g., Dhaka → Barisal): ").strip()
    
    try:
        seats = int(input("Enter Total Seats: ").strip())
    except ValueError:
        print("Invalid input! Please enter a valid number.")
        return
    
    system.add_bus(bus_number, route, seats)

def handle_book_ticket(system):
    """Handle ticket booking"""
    print("\n" + "="*40)
    print("BOOK TICKET")
    print("="*40)
    
    # Show available buses first
    system.show_buses()
    
    bus_number = input("Enter Bus Number: ").strip().upper()
    name = input("Enter Passenger Name: ").strip()
    phone = input("Enter Phone Number (01XXXXXXXXX): ").strip()
    
    system.book_ticket(bus_number, name, phone)

def handle_admin_menu(system):
    """Handle admin menu operations"""
    while True:
        if not system.admin.is_logged_in:
            break
            
        display_admin_menu()
        choice = input("Enter your choice (1-4): ").strip()
        
        if choice == '1':
            handle_add_bus(system)
        elif choice == '2':
            system.show_buses()
        elif choice == '3':
            system.show_all_passengers()
        elif choice == '4':
            system.admin_logout()
            break
        else:
            print(" Invalid choice! Please enter a number between 1 and 4.")
        
        input("\nPress Enter to continue...")
        clear_screen()

def main():
    """
    Main function to run the bus ticket booking system
    """
    
    system = BusSystem()
    
    while True:
        clear_screen()
        display_user_menu()
        
        choice = input("Enter your choice (1-4): ").strip()
        
        if choice == '1':
            # Admin Login
            clear_screen()
            if system.admin_login():
                input("\nPress Enter to continue to Admin Menu...")
                clear_screen()
                handle_admin_menu(system)
            else:
                input("\nPress Enter to continue...")
        
        elif choice == '2':
            # Book Ticket
            clear_screen()
            handle_book_ticket(system)
            input("\nPress Enter to continue...")
        
        elif choice == '3':
            # View All Buses
            clear_screen()
            system.show_buses()
            input("\nPress Enter to continue...")
        
        elif choice == '4':
            # Exit
            print("\n" + "="*50)
            print("Thank you for using Bangladesh Bus Ticket Booking System!")
            print("Have a safe journey! ")
            print("="*50 + "\n")
            break
        
        else:
            print(" Invalid choice! Please enter a number between 1 and 4.")
            input("\nPress Enter to continue...")

if __name__ == "__main__":
    main()