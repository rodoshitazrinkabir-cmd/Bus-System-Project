class Admin:
    """
    Admin class for system administration
    """
    
    
    DEFAULT_USERNAME = "admin"
    DEFAULT_PASSWORD = "1234"
    
    def __init__(self, username=DEFAULT_USERNAME, password=DEFAULT_PASSWORD):
        """
        Initialize Admin object
        
        Args:
            username (str): Admin username
            password (str): Admin password
        """
        self.username = username
        self.password = password
        self.is_logged_in = False
    
    def login(self, username, password):
        """
        Validate admin credentials
        
        Args:
            username (str): Entered username
            password (str): Entered password
            
        Returns:
            bool: True if login successful, False otherwise
        """
        if username == self.username and password == self.password:
            self.is_logged_in = True
            return True
        return False
    
    def logout(self):
        """
        Logout admin
        """
        self.is_logged_in = False
        print(" Admin logged out successfully!")