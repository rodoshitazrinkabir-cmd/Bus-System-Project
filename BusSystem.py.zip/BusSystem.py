from bus import Bus
from passenger import Passenger
from admin import Admin

class BusSystem:
    """
    Main Bus System class managing all buses and bookings
    """
    
    def __init__(self):
        """
        Initialize BusSystem with empty lists and admin
        """
        self.buses = []
        self.passengers = []
        self.admin = Admin()
        
        
        self._initialize_sample_data()
    
    def _initialize_sample_data(self):
        """
        Initialize some sample bus data
        """
        sample_buses = [
            Bus("B001", "Dhaka → Chittagong", 40),
            Bus("B002", "Dhaka → Sylhet", 35),
            Bus("B003", "Dhaka → Rajshahi", 30),
            Bus("B004", "Dhaka → Khulna", 45),
            Bus("B005", "Chittagong → Cox's Bazar", 25)
        ]
        self.buses.extend(sample_buses)
    
    def add_bus(self, number, route, seats):
        """
        Add a new bus to the system (Admin only)
        
        Args:
            number (str): Bus number
            route (str): Bus route
            seats (int): Total seats
            
        Returns:
            bool: True if successful, False otherwise
        """
        if not self.admin.is_logged_in:
            print(" Access Denied! Admin login required.")
            return False
        
        # Check if bus number already exists
        if self.find_bus(number):
            print(f"Bus {number} already exists!")
            return False
        
        # Validate seats
        if seats <= 0:
            print("Invalid number of seats!")
            return False
        
        new_bus = Bus(number, route, seats)
        self.buses.append(new_bus)
        print(f" Bus {number} added successfully!")
        return True
    
    def find_bus(self, bus_number):
        """
        Find a bus by its number
        
        Args:
            bus_number (str): Bus number to find
            
        Returns:
            Bus or None: Found bus object or None
        """
        for bus in self.buses:
            if bus.number.upper() == bus_number.upper():
                return bus
        return None
    
    def book_ticket(self, bus_number, name, phone):
        """
        Book a ticket for a passenger
        
        Args:
            bus_number (str): Bus number
            name (str): Passenger name
            phone (str): Passenger phone
            
        Returns:
            bool: True if booking successful, False otherwise
        """
        # Input validation
        if not name.strip():
            print(" Invalid name! Please enter a valid name.")
            return False
        
        if not phone.strip() or not phone.isdigit() or len(phone) < 10:
            print("Invalid phone number! Please enter a valid 11-digit phone number.")
            return False
        
        # Find the bus
        bus = self.find_bus(bus_number)
        if not bus:
            print(f"Bus {bus_number} not found!")
            return False
        
        # Check seat availability
        if bus.available_seats() <= 0:
            print(f"Sorry! Bus {bus_number} is fully booked.")
            return False
        
        # Book the seat
        if bus.book_seat():
            passenger = Passenger(name, phone, bus)
            self.passengers.append(passenger)
            passenger.display_ticket()
            print(f" Ticket booked successfully for {name}!")
            return True
        
        print(" Booking failed!")
        return False
    
    def show_buses(self):
        """
        Display all buses with their details
        """
        if not self.buses:
            print(" No buses available in the system.")
            return
        
        print("\n" + "="*70)
        print(" AVAILABLE BUSES - BANGLADESH BUS SERVICE")
        print("="*70)
        print(f"{'Bus No.':<10} {'Route':<30} {'Seats':<15} {'Available':<15}")
        print("-"*70)
        
        for bus in self.buses:
            print(f"{bus.number:<10} {bus.route:<30} {f'{bus.booked_seats}/{bus.total_seats}':<15} {bus.available_seats():<15}")
        
        print("="*70)
        print(f"Total Buses: {len(self.buses)} | Fare per ticket: ৳{Bus.FIXED_FARE}")
        print("="*70 + "\n")
    
    def show_all_passengers(self):
        """
        Display all passengers (Admin only)
        """
        if not self.admin.is_logged_in:
            print(" Access Denied! Admin login required.")
            return
        
        if not self.passengers:
            print(" No passengers booked yet.")
            return
        
        print("\n" + "="*70)
        print("👥 ALL PASSENGERS")
        print("="*70)
        print(f"{'Name':<20} {'Phone':<15} {'Bus No.':<10} {'Route':<25}")
        print("-"*70)
        
        for passenger in self.passengers:
            print(f"{passenger.name:<20} {passenger.phone:<15} {passenger.bus.number:<10} {passenger.bus.route:<25}")
        
        print("="*70)
        print(f"Total Passengers: {len(self.passengers)}")
        print("="*70 + "\n")
    
    def admin_login(self):
        """
        Handle admin login process
        """
        if self.admin.is_logged_in:
            print(" Admin is already logged in!")
            return True
        
        print("\n" + "="*40)
        print(" ADMIN LOGIN")
        print("="*40)
        
        username = input("Enter Username: ").strip()
        password = input("Enter Password: ").strip()
        
        if self.admin.login(username, password):
            print("Login successful! Welcome Admin.")
            return True
        else:
            print("Invalid credentials! Access denied.")
            return False
    
    def admin_logout(self):
        """
        Handle admin logout
        """
        if not self.admin.is_logged_in:
            print(" Admin is not logged in!")
            return
        
        self.admin.logout()