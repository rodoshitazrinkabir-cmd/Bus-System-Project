class Bus:
    """
    Bus class representing a bus with its attributes and booking functionality
    """
    FIXED_FARE = 500  
    
    def __init__(self, number, route, total_seats):
        """
        Initialize Bus object
        
        Args:
            number (str): Bus number/identifier
            route (str): Route from source to destination
            total_seats (int): Total seats in the bus
        """
        self.number = number
        self.route = route
        self.total_seats = total_seats
        self.booked_seats = 0
    
    def available_seats(self):
        """
        Calculate and return available seats
        
        Returns:
            int: Number of unbooked seats
        """
        return self.total_seats - self.booked_seats
    
    def book_seat(self):
        """
        Book a seat if available
        
        Returns:
            bool: True if booking successful, False if no seats available
        """
        if self.available_seats() > 0:
            self.booked_seats += 1
            return True
        return False
    
    def get_fare(self):
        """
        Get the fixed fare for this bus
        
        Returns:
            int: Fixed fare amount
        """
        return self.FIXED_FARE
    
    def __str__(self):
        """
        String representation of Bus object
        """
        return f"Bus {self.number} | Route: {self.route} | Seats: {self.booked_seats}/{self.total_seats} | Available: {self.available_seats()}"