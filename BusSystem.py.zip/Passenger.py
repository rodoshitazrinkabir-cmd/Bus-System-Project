class Passenger:
    """
    Passenger class representing a passenger with booking details
    """
    
    def __init__(self, name, phone, bus):
        """
        Initialize Passenger object
        
        Args:
            name (str): Passenger name
            phone (str): Passenger phone number
            bus (Bus): Reference to the Bus object
        """
        self.name = name
        self.phone = phone
        self.bus = bus
        self.fare = bus.get_fare()
    
    def display_ticket(self):
        """
        Display ticket information
        """
        print("\n" + "="*50)
        print(" BUS TICKET - BANGLADESH BUS SERVICE")
        print("="*50)
        print(f"Passenger Name: {self.name}")
        print(f"Phone Number: {self.phone}")
        print(f"Bus Number: {self.bus.number}")
        print(f"Route: {self.bus.route}")
        print(f"Fare: ৳{self.fare}")
        print("="*50)
        print("Thank you for traveling with us! ")
        print("="*50 + "\n")
    
    def __str__(self):
        """
        String representation of Passenger object
        """
        return f"{self.name} | Phone: {self.phone} | Bus: {self.bus.number} | Route: {self.bus.route}"